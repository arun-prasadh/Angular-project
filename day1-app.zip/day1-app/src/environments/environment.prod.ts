export const environment = {
  production: true,
  serverAPI:"http://localhost:8080"
};
